package pkg.exceptions;

public class PilhaCheiaException extends Exception {
  public PilhaCheiaException() {
  }

  public PilhaCheiaException(String message) {
    super(message);
  }
}
