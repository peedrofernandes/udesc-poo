package pkg.exceptions;

public class ProcessoSemJuizException extends Exception {
  public ProcessoSemJuizException() {
  }
  
  public ProcessoSemJuizException(String message) {
    super(message);
  }
}
