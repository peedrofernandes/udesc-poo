package pkg.exceptions;

public class NomeInvalidoException extends Exception {
  public NomeInvalidoException(String msg) {
    super(msg);
  }
}
