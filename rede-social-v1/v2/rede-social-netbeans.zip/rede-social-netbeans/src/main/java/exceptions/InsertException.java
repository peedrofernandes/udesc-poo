package exceptions;

public class InsertException extends Exception {
  public InsertException(String message) {
    super(message);
  }
}