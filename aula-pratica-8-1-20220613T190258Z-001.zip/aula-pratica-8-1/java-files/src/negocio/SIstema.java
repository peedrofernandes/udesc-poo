package negocio;

import persistencia.PessoaDAO;

public class SIstema {
    private PessoaDAO pessoaDAO;

    public void adicionarPessoa(Pessoa p) {

    }

    public void removerPessoa(Pessoa p) {

    }

    public List<Pessoa> getList() {
        
    }
}