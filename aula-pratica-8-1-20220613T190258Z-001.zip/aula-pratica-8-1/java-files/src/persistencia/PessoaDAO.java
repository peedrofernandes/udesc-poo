package persistencia;

import java.util.List;

import dados.Pessoa;

// Utilizará da classe ArquivoPessoaDAO para inserir, remover e obter objetos do arquivo
public class PessoaDAO {
    public void insert(Pessoa p) {
        
    }

    public void delete(Pessoa p) {

    }

    public List<Pessoa> getAll() {

    }
}