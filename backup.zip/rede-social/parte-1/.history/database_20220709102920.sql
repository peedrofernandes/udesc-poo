
CREATE TABLE usuario (
	id SERIAL,
	apelido VARCHAR(16),
	email VARCHAR(64),
	hash_senha VARCHAR(256),
	nome_completo VARCHAR(64),
	biografia VARCHAR(256),
	PRIMARY KEY (id)
);

CREATE TABLE seguido_seguidor (
	id SERIAL,
	id_seguido INTEGER,
	id_seguidor INTEGER,
	PRIMARY KEY (id),
	FOREIGN KEY (id_seguido) REFERENCES usuario,
	FOREIGN KEY (id_seguidor) REFERENCES usuario
);

CREATE TABLE conversa (
	id SERIAL,
	id_usuario_1 INTEGER,
	id_usuario_2 INTEGER,
	qtd_mensagens INTEGER,
	PRIMARY KEY (id),
	FOREIGN KEY (id_usuario_1) REFERENCES usuarios,
	FOREIGN KEY (id_usuario_2) REFERENCES usuarios
);

CREATE TABLE mensagens (
	id SERIAL,
	id_conversa INTEGER,
	id_remetente INTEGER,
	id_destinatario INTEGER,
	texto VARCHAR(256),
	data_envio DATE,
	visualizado BOOLEAN,
	recebido BOOLEAN,
	PRIMARY KEY (id),
	FOREIGN KEY (id_conversa) REFERENCES conversas,
	FOREIGN KEY (id_remetente) REFERENCES usuarios,
	FOREIGN KEY (id_destinatario) REFERENCES usuarios
);

CREATE TABLE posts (
	id SERIAL,
	id_autor INTEGER,
	foto OID,
	legenda VARCHAR(64),
	data_publicacao DATE,
	PRIMARY KEY (id),
	FOREIGN KEY (id_autor) REFERENCES usuarios
);

CREATE TABLE posts_favoritos (
	id SERIAL,
	id_usuario INTEGER,
	id_post INTEGER,
	PRIMARY KEY (id),
	FOREIGN KEY (id_usuario) REFERENCES usuarios,
	FOREIGN KEY (id_post) REFERENCES posts
);

CREATE TABLE comentarios (
	id SERIAL,
	id_post INTEGER,
	id_autor INTEGER,
	texto VARCHAR(256),
	qtd_favoritos INTEGER,
	PRIMARY KEY (id),
	FOREIGN KEY (id_post) REFERENCES posts,
	FOREIGN KEY (id_autor) REFERENCES usuarios
);

CREATE TABLE comentarios_favoritos (
	id SERIAL,
	id_usuario INTEGER,
	id_comentario INTEGER,
	PRIMARY KEY (id),
	FOREIGN KEY (id_usuario) REFERENCES usuarios,
	FOREIGN KEY (id_comentario) REFERENCES comentarios
);

