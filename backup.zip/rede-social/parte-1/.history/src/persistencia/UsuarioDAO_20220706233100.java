package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UsuarioDAO {
  private static UsuarioDAO instance = null;

  private PreparedStatement selectNextId;
  private PreparedStatement insert;
  private PreparedStatement select;
  private PreparedStatement update;
  private PreparedStatement delete;

  private UsuarioDAO() throws SQLException {
    Connection conexao = Conexao.getConexao();

    String selectNextIdQuery = "SELECT nextval('usuarios_id_seq')";
    String insertQuery = "INSERT INTO usuarios (id, apelido, email, hash_senha, ) VALUES (?,?,?,?,?,?)";
    String selectQuery = "SELECT * FROM usuario WHERE id = ?";
    String updateQuery = "UPDATE usuarios SET apelido = ?, email = ?, hash_senha = ?, nome_completo = ?, biografia = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM usuarios WHERE id = ?";

    selectNextId = conexao.prepareStatement(selectNextIdQuery);

    insert = conexao.prepareStatement(insertQuery);
    select = conexao.prepareStatement(selectQuery);
    update = conexao.prepareStatement(updateQuery);
    delete = conexao.prepareStatement(deleteQuery);
  }
  

}
