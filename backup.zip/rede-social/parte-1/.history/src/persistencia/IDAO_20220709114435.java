package persistencia;

import exceptions.InsertException;
import exceptions.SelectException;

public interface IDAO <Data> {
  protected abstract int selectNextId() throws SelectException;

  public abstract void insert(Data elem) throws SelectException, InsertException;

  public abstract Data select(int id) throws SelectException;

  public abstract void update(Data elem) throws UpdateException;

  public abstract void delete(Data elem) throws DeleteException;
}
