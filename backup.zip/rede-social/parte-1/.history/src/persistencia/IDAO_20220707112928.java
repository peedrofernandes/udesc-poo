package persistencia;

public interface IDAO <T> {
  public 
}
