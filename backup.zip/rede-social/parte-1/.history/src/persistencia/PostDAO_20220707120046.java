package persistencia;

public class PostDAO extends DAO <Post> {
  private static PostDAO instance = null;

  public static PostDAO getInstance() {
    if (instance != null) 
      return instance;

    String selectNextIdQuery = "SELECT NEXTVAL('posts_id_seq')";
    String insertQuery = ""

    return new PostDAO()
  }
}
