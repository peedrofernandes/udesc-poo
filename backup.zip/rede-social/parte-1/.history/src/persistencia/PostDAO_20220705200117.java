package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PostDAO {
  private static PostDAO instance = null;

  private PreparedStatement selectNewId;
  private PreparedStatement select;
  private PreparedStatement insert;
  private PreparedStatement delete;
  private PreparedStatement update;

  private PostDAO() throws ClassNotFoundException, SQLException {
    Connection conexao = Conexao.getConexao();

    this.selectNewId = conexao.prepareStatement("select nextval('id_endereco')");
  }

  public static PostDAO getInstance() throws ClassNotFoundException, SQLException {
    if (instance == null)
      instance = new PostDAO();

    return instance;
  }

  private int selectNewId() {
    try {
      ResultSet rs = this.selectNewId.executeQuery();

      if (rs.next())
        return rs.getInt(1);
    }
  }
}
