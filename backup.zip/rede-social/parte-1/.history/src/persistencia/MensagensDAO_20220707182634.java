package persistencia;

import java.sql.SQLException;

import dados.Mensagem;

public class MensagensDAO extends DAO <Mensagem> {
  private static MensagensDAO instance = null;

  private MensagensDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, selectQuery, insertQuery, updateQuery, deleteQuery);
  }

  public MensagensDAO getInstance() {
    // (id, id_conversa, id_remetente, id_destinatario, texto, data_envio, visualizado, recebido)
    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT nextval('mensagens_id_seq')";
    String insertQuery = "INSERT INTO mensagens (id, id_conversa, id_remetente, id_destinatario, texto, data_envio, visualizado, recebido) VALUES (?,?,?,?,?,?,?,?)";
    String selectQuery = "SELECT * FROM mensagens WHERE id = ?";
    String updateQuery = "UPDATE mensagens SET id_conversa = ?, id_remetente = ?, id_destinatario = ?, texto = ?, data_envio = ?, visualizado = ?, recebido = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM mensagens WHERE id = ?";

    return new MensagensDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);
  }
}
