package persistencia;

import java.sql.ResultSet;
import java.sql.SQLException;

import dados.Comentario;
import exceptions.InsertException;
import exceptions.SelectException;

public class ComentariosDAO extends DAO<Comentario> {
  private static ComentariosDAO instance = null;

  public ComentariosDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);
  }
  
  public static ComentariosDAO getInstance() throws SQLException {
    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT nextval('comentarios_id_seq')";
    String insertQuery = "INSERT INTO comentarios (id, id_post, id_autor, texto, qtd_favoritos VALUES (?,?,?,?,?)";
    String selectQuery = "SELECT * FROM comentarios WHERE id = ?";
    String updateQuery = "UPDATE comentarios SET id_post = ?, id_autor = ?, texto = ?, qtd_favoritos = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM comentarios WHERE id = ?";

    instance = new ComentariosDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);

    return instance;
  }

  private int selectNextIdQuery() throws SelectException {
    try {
      ResultSet result = selectNextId.executeQuery();
      if (result.next())
        return result.getInt(1);
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível obter o próximo ID da tabela de comentários!");
    }

    return 0;
  }

  public void insertQuery(Comentario c) throws InsertException {
    // (id, id_post, id_autor, texto, qtd_favoritos)
    try {
      insert.setInt(1, c.getId());
      insert.setInt(2, c.getPost().getId());
      insert.setInt(3, c.getAutor().getId());
      insert
    }
  }
}
