package persistencia;

import java.sql.SQLException;

import dados.Comentario;

public class ComentariosDAO extends DAO<Comentario> {
  private static ComentariosDAO instance = null;

  public ComentariosDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);
  }
  
  public static ComentariosDAO getInstance() {
    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT nextval('comentarios_id_seq')";
    String insertQuery = "INSERT INTO comentarios (id, id_post, id_autor, texto, qtd_favoritos VALUES (?,?,?,?,?)";
    String selectQuery = "SELECT * FROM comentarios WHERE id = ?";
    String updateQuery = "UPDATE comentarios SET id_post = ?, id_autor = ?, texto = ?, qtd_favoritos = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM comentarios WHERE id = ?";

    return new ComentariosDAO()
  }
}
