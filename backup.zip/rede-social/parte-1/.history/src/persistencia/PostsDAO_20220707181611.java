package persistencia;

import java.io.File;
import java.sql.Blob;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import dados.Post;
import dados.Usuario;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class PostsDAO extends DAO <Post> {
  private static PostsDAO instance = null;

  private static UsuariosDAO usuariosDAO = null;

  public static PostsDAO getInstance() throws SQLException {
    // (id, id_autor, foto, legenda, data_publicacao)

    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT NEXTVAL('posts_id_seq')";
    String insertQuery = "INSERT INTO posts (id, id_autor, foto, legenda, data_publicacao) VALUES (?,?,?,?,?)";
    String selectQuery = "SELECT * FROM posts WHERE id = ?";
    String updateQuery = "UPDATE posts SET id_autor = ?, foto = ?, legenda = ?, data_publicacao = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM posts WHERE id = ?";

    return new PostsDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);
  }
  
  private PostsDAO(
      String selectNextIdQuery,
      String insertQuery,
      String selectQuery,
      String updateQuery,
      String deleteQuery) throws SQLException {
    super(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);

    usuariosDAO = UsuariosDAO.getInstance();
  }

  public int selectNextId() throws SelectException {
    try {
      ResultSet result = selectNextId.executeQuery();
      if (result.next())
        return result.getInt(1);
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível obter o próximo ID de Posts!");
    }

    return 0;
  }

  public void insert(Post p) throws InsertException, SelectException {
    // (id, id_autor, foto, legenda, data_publicacao)
    try {
      int idPost = selectNextId();
      insert.setInt(1, idPost);
      insert.setInt(2, p.getAutor().getId());
      insert.setBlob(3, p.getFoto());
      insert.setString(4, p.getLegenda());
      insert.setDate(5, p.getDataPublicacao());
      insert.executeUpdate();
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível inserir um novo post na tabela posts!\nDetalhes: " + exc.getMessage());
    }
  }

  public Post select(int idPost) throws SelectException {
    // (id, id_autor, foto, legenda, data_publicacao)
    try {
      select.setInt(1, idPost);
      ResultSet result = select.executeQuery();
      if (result.next()) {
        int id = result.getInt(1);
        int idAutor = result.getInt(2);
        Blob foto = result.getBlob(3);
        String legenda = result.getString(4);
        Date dataPublicacao = result.getDate(5);

        Usuario autor = usuariosDAO.select(idAutor);

        return new Post(id, autor, foto, legenda, dataPublicacao);
      }
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível selecionar o post especificado de id " + idPost + "!");
    }

    return null;
  }
  
  public void update(Post p) throws UpdateException {
    // id_autor, foto, legenda, data_publicacao, id;
    try {
      update.setInt(1, p.getAutor().getId());
      update.setBlob(2, p.getFoto());
      update.setString(3, p.getLegenda());)
    }
  }
}
