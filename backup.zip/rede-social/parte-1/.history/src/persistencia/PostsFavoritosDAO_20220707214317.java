package persistencia;

import java.sql.SQLException;

public class PostsFavoritosDAO {
  private static PostsFavoritosDAO instance = null;

  private PostsFavoritosDAO(

  ) throws SQLException {
    String selectNextIdQuery,
    String selectByUsuarioQuery,
    String selectByPostQuery,
    String selectQuery,
    String deleteQuery
  }
}
