package persistencia;

import dados.Conversa;

public class ConversasDAO extends DAO <Conversa> {
  private static ConversasDAO instance = null;

  protected ConversasDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String 
  )
}
