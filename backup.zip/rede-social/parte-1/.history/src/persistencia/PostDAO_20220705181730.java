package persistencia;

public class PostDAO {
  
}
