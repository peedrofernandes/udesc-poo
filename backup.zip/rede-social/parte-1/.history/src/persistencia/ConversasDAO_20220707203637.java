package persistencia;

import java.sql.SQLException;

import dados.Conversa;

public class ConversasDAO extends DAO <Conversa> {
  private static ConversasDAO instance = null;

  protected ConversasDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, selectQuery, insertQuery, updateQuery, deleteQuery);
  }

  public ConversasDAO getInstance() {
    if (instance != null) 
      return instance;

    String selectNextIdQuery = "SELECT nextval('conversas_id_seq')"

    instance = new ConversasDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);


  }
}
