package persistencia;

import java.sql.ResultSet;
import java.sql.SQLException;

import dados.Mensagem;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class MensagensDAO extends DAO <Mensagem> {
  private static MensagensDAO instance = null;

  private MensagensDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, selectQuery, insertQuery, updateQuery, deleteQuery);
  }

  public MensagensDAO getInstance() throws SQLException {
    // (id, id_conversa, id_remetente, id_destinatario, texto, data_envio, visualizado, recebido)
    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT nextval('mensagens_id_seq')";
    String insertQuery = "INSERT INTO mensagens (id, id_conversa, id_remetente, id_destinatario, texto, data_envio, visualizado, recebido) VALUES (?,?,?,?,?,?,?,?)";
    String selectQuery = "SELECT * FROM mensagens WHERE id = ?";
    String updateQuery = "UPDATE mensagens SET id_conversa = ?, id_remetente = ?, id_destinatario = ?, texto = ?, data_envio = ?, visualizado = ?, recebido = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM mensagens WHERE id = ?";

    instance = new MensagensDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);

    return instance;
  }

  protected int selectNextId() throws SelectException {
    try {
      ResultSet result = selectNextId.executeQuery();

      if (result.next())
        return result.getInt(1);
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível obter o próximo ID da tabela de mensagens!");
    }

    return 0;
  }
  
  public void insert(Mensagem m) throws InsertException, SelectException {
    // (id, id_conversa, id_remetente, id_destinatario, texto, data_envio, visualizado, recebido)
    try {
      int idMensagem = selectNextId();
      insert.setInt(1, idMensagem);
      insert.setInt(2, m.getConversa().getId());
      insert.setInt(3, m.getRemetente().getId());
      insert.setInt(4, m.getDestinatario().getId());
      insert.setString(5, m.getTexto());
      insert.setDate(6, m.getData());
      insert.setBoolean(7, m.isVisualizado());
      insert.setBoolean(8, m.isRecebido());

      insert.executeUpdate();
    } catch (SQLException exc) {
      throw new InsertException("Não foi possível inserir uma nova mensagem na tabela de mensagens!");
    }
  }

  public Mensagem select(int idMensagem) 
}
