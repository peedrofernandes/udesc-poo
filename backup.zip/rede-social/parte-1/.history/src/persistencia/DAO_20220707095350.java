package persistencia;

import java.sql.PreparedStatement;

public abstract class DAO <T> {
  private PreparedStatement selectNextId;
  private PreparedStatement select;
  private PreparedStatement insert;
  private PreparedStatement update;
  private PreparedStatement delete;

  protected abstract int selectNextId();

  public abstract T select(int id);

  public abstract T insert()
}
