package persistencia;

public abstract class DAO {
  
}
