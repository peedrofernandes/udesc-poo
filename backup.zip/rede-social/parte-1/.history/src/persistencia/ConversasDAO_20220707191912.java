package persistencia;

import dados.Conversa;

public class ConversasDAO extends DAO <Conversa> {
  
}
