package persistencia;

import java.sql.SQLException;

import dados.Post;

public class PostDAO extends DAO <Post> {
  private static PostDAO instance = null;

  public static PostDAO getInstance() throws SQLException {
    // (id, id_autor, foto, legenda, data_publicacao)

    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT NEXTVAL('posts_id_seq')";
    String insertQuery = "INSERT INTO posts (id, id_autor, foto, legenda, data_publicacao) VALUES (?,?,?,?,?)";
    String selectQuery = "SELECT * FROM posts WHERE id = ?";
    String updateQuery = "UPDATE posts SET id_autor = ?, foto = ?, legenda = ?, data_publicacao = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM posts WHERE id = ?";

    return new PostDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);
  }
  
  private PostDAO(
      String selectNextIdQuery,
      String insertQuery,
      String selectQuery,
      String updateQuery,
      String deleteQuery) throws SQLException {
    super(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);
  }

  public int selectNextId() {
    try {
      selectNex
    }
  }
}
