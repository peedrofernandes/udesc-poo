package persistencia;

import java.sql.PreparedStatement;

import exceptions.SelectException;

public interface IDAO <T> {
  public PreparedStatement selectNextId;
  public PreparedStatement insert;
  public PreparedStatement select;
  public PreparedStatement update;
  public PreparedStatement delete;

  public int selectNextId() throws SelectException;

  public void insert(T elem) throws SelectException, InsertException;

  public T select(int id) throws SelectException;

  public void update(T elem) throws UpdateException;

  public void delete(T elem) throws DeleteException;
}
