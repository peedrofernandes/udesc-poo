package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dados.Usuario;
import exceptions.DeleteException;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class UsuarioDAO extends DAO <Usuario> {
  private static UsuarioDAO instance = null;

  private PreparedStatement selectMensagensEnviadas;
  private PreparedStatement selectConversas;
  private PreparedStatement selectPosts;
  private PreparedStatement selectCurtidasComentarios;
  private PreparedStatement selectCurtidasPosts;
  private PreparedStatement selectMensagensRecebidas;
  private PreparedStatement selectComentarios;
  private PreparedStatement selectSeguidores;
  private PreparedStatement selectSeguidos;
  
  private PreparedStatement insertSeguido;
  private PreparedStatement deleteSeguido;
  

  private UsuarioDAO() throws SQLException {
    selectNextId = conexao.prepareStatement("SELECT nextval('usuarios_id_seq')");
    insert = conexao.prepareStatement("INSERT INTO usuarios (id, apelido, email, hash_senha, nome_completo, biografia) VALUES (?,?,?,?,?,?)");
    select = conexao.prepareStatement("SELECT * FROM usuario WHERE id = ?");
    update = conexao.prepareStatement("UPDATE usuarios SET apelido = ?, email = ?, hash_senha = ?, nome_completo = ?, biografia = ? WHERE id = ?");
    delete = conexao.prepareStatement("DELETE FROM usuarios WHERE id = ?");

    selectMensagensEnviadas = conexao.prepareStatement("SELECT * FROM mensagem WHERE id_autor = ?");
    selectConversas = conexao.prepareStatement("SELECT * FROM conversa WHERE id_usuario_1 = ? OR id_usuario_2 = ?");
    selectPosts = conexao.prepareStatement("SELECT * FROM post WHERE id_autor = ?");
    selectCurtidasComentarios = conexao.prepareStatement("SELECT * FROM comentario_favorito WHERE id_usuario = ?");
    selectCurtidasPosts = conexao.prepareStatement("SELECT * FROM post_favorito WHERE id_usuario = ?");
    selectMensagensRecebidas = conexao.prepareStatement("SELECT * FROM mensagem WHERE (SELECT * FROM conversa WHERE ")

  }

  public static UsuarioDAO getInstance() throws SQLException {
    if (instance != null)
      return instance;
    instance = new UsuarioDAO();
    return instance;
  }

  protected int selectNextId() throws SelectException {
    try {
      ResultSet result = selectNextId.executeQuery();

      if (result.next())
        return result.getInt(1);

    } catch (SQLException exc) {
      throw new SelectException("Não foi possível selecionar o próximo ID da tabela de usuários!");
    }

    return 0;
  }

  public void insert(Usuario u) throws SelectException, InsertException {
    // (id, apelido, email, hash_senha, nome_completo, biografia)
    try {
      insert.setInt(1, selectNextId());
      insert.setString(2, u.getApelido());
      insert.setString(3, u.getEmail());
      insert.setString(4, u.getHashSenha());
      insert.setString(5, u.getNomeCompleto());
      insert.setString(6, u.getBiografia());

      insert.executeUpdate();
    } catch (SQLException exc) {
      throw new InsertException("Não foi possível inserir um novo usuário!");
    }
  }

  public Usuario select(int idConsulta) throws SelectException {
    // (id, apelido, email, hash_senha, nome_completo, biografia)
    try {
      select.setInt(1, idConsulta);
      ResultSet result = select.executeQuery();

      if (result.next()) {
        int id = result.getInt(1);
        String apelido = result.getString(2);
        String email = result.getString(3);
        String hashSenha = result.getString(4);
        String nomeCompleto = result.getString(5);
        String biografia = result.getString(6);

        return new Usuario(id, apelido, email, hashSenha, nomeCompleto, biografia);
      }
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível encontrar o usuário especificado de id " + idConsulta + "!");
    }

    return null;
  }

  public void update(Usuario u) throws UpdateException {
    // (apelido, email, hash_senha, nome_completo, biografia, id)
    try {
      update.setString(1, u.getApelido());
      update.setString(2, u.getEmail());
      update.setString(3, u.getHashSenha());
      update.setString(4, u.getNomeCompleto());
      update.setString(5, u.getBiografia());
      update.setInt(6, u.getId());

      update.executeUpdate();
    } catch (SQLException exc) {
      throw new UpdateException("Não foi possível atualizar o usuário " + u.getApelido() + "! (id: " + u.getId() + ")");
    }
  }

  public void delete(Usuario u) throws DeleteException {
    try {
      delete.setInt(1, u.getId());
      delete.executeUpdate();
    } catch (SQLException exc) {
      throw new DeleteException("Não foi possível excluir o usuário " + u.getApelido() + "! (id: " + u.getId() + ")");
    }
  }
}