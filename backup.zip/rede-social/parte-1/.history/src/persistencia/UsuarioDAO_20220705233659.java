package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class UsuarioDAO {
  private static UsuarioDAO instance = null;

  private PreparedStatement selectNextId;
  private PreparedStatement select;
  private PreparedStatement insert;
  private PreparedStatement update;
  private PreparedStatement delete;

  private UsuarioDAO() {
    Connection conexao = Conexao.getConexao();

    selectNextId = conexao.prepareStatement("SELECT NEXTVAL('id')");
    select = conexao.prepareStatement("SELECT * FROM usuario WHERE ")
  }
}
