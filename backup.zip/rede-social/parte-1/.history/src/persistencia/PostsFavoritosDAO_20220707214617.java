package persistencia;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PostsFavoritosDAO {
  private static PostsFavoritosDAO instance = null;

  private PreparedStatement selectNextId;
  private PreparedStatement selectByUsuario;
  private PreparedStatement selectByPost;
  private PreparedStatement select;
  private PreparedStatement delete;

  private PostsFavoritosDAO() throws SQLException {
    String selectNextIdQuery = "SELECT nextval('posts_favoritos_id_seq')";
    String selectByUsuarioQuery = "SELECT * FROM posts_favoritos WHERE id_usuario = ?";
    String selectByPostQuery = "SELECT * FROM posts_favoritos WHERE id_post = ?";
    String selectQuery = "SELECT * FROM posts_favoritos WHERE id = ?";
    String deleteQuery = "DELETE FROM posts_favoritos WHERE id = ?";


  }
}
