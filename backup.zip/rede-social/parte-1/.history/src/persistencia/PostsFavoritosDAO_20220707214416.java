package persistencia;

import java.sql.SQLException;

public class PostsFavoritosDAO {
  private static PostsFavoritosDAO instance = null;

  private PostsFavoritosDAO() throws SQLException {
    String selectNextIdQuery = "SELECT nextval('posts_favoritos_id_seq')";
    String selectByUsuarioQuery = "SELECT * FROM posts_favoritos WHERE id"
    String selectByPostQuery,
    String selectQuery,
    String deleteQuery
  }
}
