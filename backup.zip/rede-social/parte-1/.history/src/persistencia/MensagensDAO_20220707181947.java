package persistencia;

public class MensagensDAO extends DAO <Mensagem> {
  
}
