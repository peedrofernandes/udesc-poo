package persistencia;

public class PostsFavoritosDAO {
  private static PostsFavoritosDAO instance = null;

  private PostsFavoritosDAO()
}
