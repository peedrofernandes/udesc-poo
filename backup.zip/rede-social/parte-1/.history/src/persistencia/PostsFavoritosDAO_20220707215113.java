package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import exceptions.SelectException;

public class PostsFavoritosDAO {
  private static PostsFavoritosDAO instance = null;

  private PreparedStatement selectNextId;
  private PreparedStatement selectByUsuario;
  private PreparedStatement selectByPost;
  private PreparedStatement select;
  private PreparedStatement delete;

  private PostsFavoritosDAO() throws SQLException {
    Connection conexao = Conexao.getConexao();

    selectNextId = conexao.prepareStatement("SELECT nextval('posts_favoritos_id_seq')");
    selectByUsuario = conexao.prepareStatement("SELECT * FROM posts_favoritos WHERE id_usuario = ?");
    selectByPost = conexao.prepareStatement("SELECT * FROM posts_favoritos WHERE id_post = ?");
    select = conexao.prepareStatement("SELECT * FROM posts_favoritos WHERE id = ?");
    delete = conexao.prepareStatement("DELETE FROM posts_favoritos WHERE id = ?");
  }

  public PostsFavoritosDAO getInstance() throws SQLException {
    if (instance != null)
      return instance;

    instance = new PostsFavoritosDAO();
    return instance;
  }

  private int selectNextId() throws SelectException {
    try {
      ResultSet result = selectNextId.executeQuery();
      if (result.next())
        return result.getInt(1);
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível obter o próximo ID da tabela de posts favoritos!");
    }

    return 0;
  }

  
}
