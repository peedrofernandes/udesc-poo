package persistencia;

import dados.Mensagem;

public class MensagensDAO extends DAO <Mensagem> {
  private static MensagensDAO instance = null;

  private MensagensDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) {
    super(selectNextIdQuery, selectQuery, insertQuery, updateQuery, deleteQuery);
  }
}
