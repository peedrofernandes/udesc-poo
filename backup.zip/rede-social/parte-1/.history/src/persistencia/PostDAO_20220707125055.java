package persistencia;

import dados.Post;

public class PostDAO extends DAO <Post> {
  private static PostDAO instance = null;

  public static PostDAO getInstance() {
    // (id, id_autor, foto, legenda, data_publicacao)

    if (instance != null) 
      return instance;

    String selectNextIdQuery = "SELECT NEXTVAL('posts_id_seq')";
    String insertQuery = "INSERT INTO posts (id, id_autor, foto, legenda, data_publicacao)";
    String selectQuery = 

    return new PostDAO()
  }
}
