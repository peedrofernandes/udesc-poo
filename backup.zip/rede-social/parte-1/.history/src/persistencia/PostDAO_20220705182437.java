package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PostDAO {
  private static PostDAO instance = null;

  private PreparedStatement select;
  private PreparedStatement insert;
  private PreparedStatement delete;
  private PreparedStatement update;

  private PostDAO() throws ClassNotFoundException, SQLException {
    Connection conexao = Conexao.getInstancia();

    
  }

  public static PostDAO getInstance() throws ClassNotFoundException, SQLException {
    if (instance == null)
      instance = new PostDAO();

    return instance;
  }
}
