package persistencia;

import java.sql.PreparedStatement;

import exceptions.DeleteException;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public abstract class DAO <T> {
  protected PreparedStatement selectNextId;
  protected PreparedStatement select;
  protected PreparedStatement insert;
  protected PreparedStatement update;
  protected PreparedStatement delete;

  

  protected abstract int selectNextId() throws SelectException;

  public abstract void insert(T elem) throws SelectException, InsertException;

  public abstract T select(int id) throws SelectException;

  public abstract void update(T elem) throws UpdateException;

  public abstract void delete(T elem) throws DeleteException;
}
