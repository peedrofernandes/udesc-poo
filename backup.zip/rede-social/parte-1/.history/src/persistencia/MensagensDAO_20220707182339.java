package persistencia;

import java.sql.SQLException;

import dados.Mensagem;

public class MensagensDAO extends DAO <Mensagem> {
  private static MensagensDAO instance = null;

  private MensagensDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, selectQuery, insertQuery, updateQuery, deleteQuery);
  }

  public MensagensDAO getInstance() {
    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT nextval('mensagens_id_seq')";
    String insertQuery = "INSERT INTO mensagens ("
  }
}
