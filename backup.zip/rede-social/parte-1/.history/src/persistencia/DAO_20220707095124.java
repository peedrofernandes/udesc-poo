package persistencia;

import java.sql.PreparedStatement;

public abstract class DAO {
  private PreparedStatement selectNextId;
  private PreparedStatement select;
  private PreparedStatement insert;
  private PreparedStatement update;
  private PreparedStatement delete;

  private int selectNextId();

  
}
