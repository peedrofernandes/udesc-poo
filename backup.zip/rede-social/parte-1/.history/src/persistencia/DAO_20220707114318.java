package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import exceptions.DeleteException;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public abstract class DAO <Data> {
  protected DataDAO instance = null;

  protected PreparedStatement selectNextId;
  protected PreparedStatement select;
  protected PreparedStatement insert;
  protected PreparedStatement update;
  protected PreparedStatement delete;

  protected static Connection conexao;

  protected DAO (
    String selectNextIdQuery,
    String selectQuery,
    String insertQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    conexao = Conexao.getConexao();

    selectNextId = conexao.prepareStatement(selectNextIdQuery);
    select = conexao.prepareStatement(selectQuery);
    insert = conexao.prepareStatement(insertQuery);
    update = conexao.prepareStatement(updateQuery);
    delete = conexao.prepareStatement(deleteQuery);
  }

  public DataDAO getInstance() {
    if (this.instance != null) {
      return this.instance;
    }

    return new DataDAO()
  }

  protected abstract int selectNextId() throws SelectException;

  public abstract void insert(Data elem) throws SelectException, InsertException;

  public abstract Data select(int id) throws SelectException;

  public abstract void update(Data elem) throws UpdateException;

  public abstract void delete(Data elem) throws DeleteException;
}
