package persistencia;

import dados.Comentario;

public class ComentariosDAO extends DAO<Comentario> {
  private 
}
