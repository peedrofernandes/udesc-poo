package persistencia;

import java.sql.ResultSet;
import java.sql.SQLException;

import dados.Conversa;
import exceptions.SelectException;

public class ConversasDAO extends DAO <Conversa> {
  private static ConversasDAO instance = null;

  protected ConversasDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, selectQuery, insertQuery, updateQuery, deleteQuery);
  }

  public ConversasDAO getInstance() throws SQLException {
    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT nextval('conversas_id_seq')";
    String insertQuery = "INSERT INTO conversas (id, id_usuario_1, id_usuario_2, qtd_mensagens) VALUES (?,?,?,?)";
    String selectQuery = "SELECT * FROM conversas WHERE id = ?";
    String updateQuery = "UPDATE conversas SET id_usuario_1 = ?, id_usuario_2 = ?, qtd_mensagens = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM conversas WHERE id = ?";

    instance = new ConversasDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);

    return instance;
  }
  
  protected int selectNextId() throws SelectException {
    try {
      ResultSet result = selectNextId.executeQuery();

      if (result.next())
        return result.getInt(1);
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível obter o próximo ID da tabela de conversas!");
    }

    return null;
  }

  public void insert()
}
