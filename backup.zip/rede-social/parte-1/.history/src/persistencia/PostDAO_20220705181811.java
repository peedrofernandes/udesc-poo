package persistencia;

public class PostDAO {
  private static PostDAO instance = null;

  private 
}
