package persistencia;

import java.sql.ResultSet;
import java.sql.SQLException;

import dados.Mensagem;
import exceptions.SelectException;

public class MensagensDAO extends DAO <Mensagem> {
  private static MensagensDAO instance = null;

  private MensagensDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, selectQuery, insertQuery, updateQuery, deleteQuery);
  }

  public MensagensDAO getInstance() throws SQLException {
    // (id, id_conversa, id_remetente, id_destinatario, texto, data_envio, visualizado, recebido)
    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT nextval('mensagens_id_seq')";
    String insertQuery = "INSERT INTO mensagens (id, id_conversa, id_remetente, id_destinatario, texto, data_envio, visualizado, recebido) VALUES (?,?,?,?,?,?,?,?)";
    String selectQuery = "SELECT * FROM mensagens WHERE id = ?";
    String updateQuery = "UPDATE mensagens SET id_conversa = ?, id_remetente = ?, id_destinatario = ?, texto = ?, data_envio = ?, visualizado = ?, recebido = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM mensagens WHERE id = ?";

    instance = new MensagensDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);

    return instance;
  }

  private int selectNextId() throws SelectException {
    try {
      ResultSet result = selectNextId.executeQuery();

      if (result.next())
        return result.getInt(1);
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível obter o próximo ID da tabela de mensagens!");
    } 
  }
}
