package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UsuarioDAO {
  private static UsuarioDAO instance = null;

  private PreparedStatement selectNextId;
  private PreparedStatement insert;
  private PreparedStatement select;
  private PreparedStatement update;
  private PreparedStatement delete;

  private UsuarioDAO() throws SQLException {
    Connection conexao = Conexao.getConexao();

    String selectNextIdQuery = "SELECT nextval('usuarios_id_seq')";
    String insertQuery = "INSERT INTO usuarios VALUES (?,?,?,?,?,?)";
    String selectQuery = "SELECT * FROM usuario WHERE id = ?";
    String updateQuery = "UPDATE usuarios SET apelido = ?, "

    selectNextId = conexao.prepareStatement("SELECT NEXTVAL('id')");
    select = conexao.prepareStatement("SELECT * FROM usuario WHERE ? = ?");
    // insert = conexao.prepareStatement(
    //     "INSERT INTO usuario (apelido, email, hash_senha, nome_completo, biografia) VALUES (?,?,?,?,?)");
    
    select.setString
  }
}
