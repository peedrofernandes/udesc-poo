package persistencia;

import java.sql.ResultSet;
import java.sql.SQLException;

import dados.Conversa;
import dados.Usuario;
import exceptions.InsertException;
import exceptions.SelectException;

public class ConversasDAO extends DAO <Conversa> {
  private static ConversasDAO instance = null;

  private static UsuariosDAO usuariosDAO = null;

  protected ConversasDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, selectQuery, insertQuery, updateQuery, deleteQuery);
    usuariosDAO = UsuariosDAO.getInstance();
  }

  public ConversasDAO getInstance() throws SQLException {
    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT nextval('conversas_id_seq')";
    String insertQuery = "INSERT INTO conversas (id, id_usuario_1, id_usuario_2, qtd_mensagens) VALUES (?,?,?,?)";
    String selectQuery = "SELECT * FROM conversas WHERE id = ?";
    String updateQuery = "UPDATE conversas SET id_usuario_1 = ?, id_usuario_2 = ?, qtd_mensagens = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM conversas WHERE id = ?";

    instance = new ConversasDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);

    return instance;
  }
  
  protected int selectNextId() throws SelectException {
    try {
      ResultSet result = selectNextId.executeQuery();

      if (result.next())
        return result.getInt(1);
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível obter o próximo ID da tabela de conversas!");
    }

    return 0;
  }

  public void insert(Conversa c) throws InsertException, SelectException {
    // (id, id_usuario_1, id_usuario_2, qtd_mensagens)
    try {
      int idConversa = selectNextId();
      insert.setInt(1, idConversa);
      insert.setInt(2, c.getUsuario1().getId());
      insert.setInt(3, c.getUsuario2().getId());
      insert.setInt(4, c.getQtdMensagens());
      insert.executeUpdate();
    } catch (SQLException exc) {
      throw new InsertException("Não foi possível inserir uma conversa na tabela de conversas!");
    }
  }

  public Conversa select(int idConversa) throws SelectException {
    // (id, id_usuario_1, id_usuario_2, qtd_mensagens)
    try {
      select.setInt(1, idConversa);
      ResultSet result = select.executeQuery();

      if (result.next()) {
        int id = result.getInt(1);
        int idUsuario1 = result.getInt(2);
        int idUsuario2 = result.getInt(3);
        int qtdConversas = result.getInt(4);

        Usuario u1 = usuariosDAO.select(idUsuario1);
        Usuario u2 = usuariosDAO.select(idUsuario2);

        return new Conversa(id, u1, u2, qtdConversas);
      }
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível selecionar uma conversa da tabela de conversas!");
    }

    return null;
  }

  
}
