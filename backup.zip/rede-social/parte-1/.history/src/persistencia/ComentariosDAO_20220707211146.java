package persistencia;

import java.sql.SQLException;

import dados.Comentario;

public class ComentariosDAO extends DAO<Comentario> {
  private static ComentariosDAO instance = null;

  public ComentariosDAO(
    String selectNextIdQuery,
    String insertQuery,
    String selectQuery,
    String updateQuery,
    String deleteQuery
  ) throws SQLException {
    super(selectNextIdQuery, selectQuery, insertQuery, updateQuery, deleteQuery);    
  }
}
