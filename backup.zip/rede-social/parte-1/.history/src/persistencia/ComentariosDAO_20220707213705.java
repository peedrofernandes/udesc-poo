package persistencia;

import java.sql.ResultSet;
import java.sql.SQLException;

import dados.Comentario;
import dados.Post;
import dados.Usuario;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class ComentariosDAO extends DAO<Comentario> {
  private static ComentariosDAO instance = null;

  private static PostsDAO postsDAO = null;
  private static UsuariosDAO usuariosDAO = null;

  public ComentariosDAO(
      String selectNextIdQuery,
      String insertQuery,
      String selectQuery,
      String updateQuery,
      String deleteQuery) throws SQLException {
    super(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);

    postsDAO = PostsDAO.getInstance();
    usuariosDAO = UsuariosDAO.getInstance();
  }

  public static ComentariosDAO getInstance() throws SQLException {
    if (instance != null)
      return instance;

    String selectNextIdQuery = "SELECT nextval('comentarios_id_seq')";
    String insertQuery = "INSERT INTO comentarios (id, id_post, id_autor, texto, qtd_favoritos VALUES (?,?,?,?,?)";
    String selectQuery = "SELECT * FROM comentarios WHERE id = ?";
    String updateQuery = "UPDATE comentarios SET id_post = ?, id_autor = ?, texto = ?, qtd_favoritos = ? WHERE id = ?";
    String deleteQuery = "DELETE FROM comentarios WHERE id = ?";

    instance = new ComentariosDAO(selectNextIdQuery, insertQuery, selectQuery, updateQuery, deleteQuery);

    return instance;
  }

  protected int selectNextId() throws SelectException {
    try {
      ResultSet result = selectNextId.executeQuery();
      if (result.next())
        return result.getInt(1);
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível obter o próximo ID da tabela de comentários!");
    }

    return 0;
  }

  public void insert(Comentario c) throws InsertException, SelectException {
    // (id, id_post, id_autor, texto, qtd_favoritos)
    try {
      int idConversa = selectNextId();
      insert.setInt(1, idConversa);
      insert.setInt(2, c.getPost().getId());
      insert.setInt(3, c.getAutor().getId());
      insert.setString(4, c.getTexto());
      insert.setInt(5, c.getQtdFavoritos());
      insert.executeUpdate();
    } catch (SQLException exc) {
      throw new InsertException("Não foi possível inserir um novo registro na tabela de comentários!");
    }
  }

  public Comentario select(int idComentario) throws SelectException {
    // (id, id_post, id_autor, texto, qtd_favoritos)
    try {
      select.setInt(1, idComentario);
      ResultSet result = select.executeQuery();
      if (result.next()) {
        int id = result.getInt(1);
        int idPost = result.getInt(2);
        int idAutor = result.getInt(3);
        String texto = result.getString(4);
        int qtdFavoritos = result.getInt(5);

        Post post = postsDAO.select(idPost);
        Usuario autor = usuariosDAO.select(idAutor);

        return new Comentario(id, post, autor, texto, qtdFavoritos);
      }
    } catch (SQLException exc) {
      throw new SelectException("Não foi possível selecionar um registro na tabela de comentários!");
    }

    return null;
  }

  public void update(Comentario c) throws UpdateException {
    // (id, id_post, id_autor, texto, qtd_favoritos)
    try {
      update.setInt(1, c.getPost().getId());

    }
  }
}

