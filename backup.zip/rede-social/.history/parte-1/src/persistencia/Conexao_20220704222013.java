package persistencia;

import java.sql.Connection;

public class Conexao {
  private String senha;
  private Connection instancia;

  public Connection getConnection() {
    try {
      Class.forName("jdbc:postgresql://localhost:5432/mydb")
    }
  }

  public void setSenha(String senha) {
    this.senha = senha;
  }
}