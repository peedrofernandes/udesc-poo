package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
  private static String senha;
  private static String usuario;
  private static Connection instancia;

  private Conexao() {
  };

  public static Connection getInstancia() {
    if (instancia != null)
      return instancia;
    try {
      String url = "jdbc:postgresql://localhost:5432/rede-social";
      Class.forName("org.postgresql.Driver");
      instancia = DriverManager.getConnection(url, usuario, senha);
    } catch (ClassNotFoundException exc) {
      System.err.println("A classe do driver JDBC não foi encontrada! Detalhes: " + exc.getMessage());
    } catch (SQLException exc) {
      System.err.println("")
    }

    return instancia;
  }

  public static void setSenha(String s) {
    senha = s;
  }

  public static void setUsuario(String u) {
    usuario = u;
  }
}