package persistencia;

public class Conexao {
  private String senha;
  private Connection instancia;
}