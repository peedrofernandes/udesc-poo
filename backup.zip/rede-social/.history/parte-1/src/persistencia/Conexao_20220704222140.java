package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
  private String senha;
  private Connection instancia;

  public Connection getConnection() {
    try {
      Class.forName("org.postgresql.Driver");

      String url = "jdbc:postgresql://localhost:5432/rede-social";
      Connection 
    }
  }

  public void setSenha(String senha) {
    this.senha = senha;
  }
}