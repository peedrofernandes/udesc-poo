package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
  private String senha;
  private Connection instancia;

  private Conexao() {
  };

  public static Connection getInstancia

  public static void setSenha(String senha) {
    this.senha = senha;
  }
}