package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
  private static String senha;
  private static Connection instancia;

  private Conexao() {
  };

  public static Connection getInstancia() {
    if (instancia == null) {
      
    }

    return instancia;
  }

  public static void setSenha(String senha) {
    this.senha = senha;
  }
}