package persistencia;

public class Conexao {
  
}