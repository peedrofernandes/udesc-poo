package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
  private static String senha;
  private static String usuario;
  private static Connection instancia;

  private Conexao() {
  };

  public static Connection getInstancia() throws ClassNotFoundException, SQLException {
    if (instancia != null)
      return instancia;

    String url = "jdbc:postgresql://localhost:5432/rede-social";
    Class.forName("org.postgresql.Driver");
    instancia = DriverManager.getConnection(url, usuario, senha);

    return instancia;
  }

  public static void setSenha(String s) {
    senha = s;
  }

  public static void setUsuario(String u) {
    usuario = u;
  }
}