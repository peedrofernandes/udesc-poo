package persistencia;

import java.sql.Connection;

public class Conexao {
  private String senha;
  private Connection instancia;

  public getConnection() {

  }

  public void setSenha(String senha) {
    this.senha = senha;
  }
}