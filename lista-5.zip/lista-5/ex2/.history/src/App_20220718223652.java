import pkg.Animais;
import pkg.AnimaisFactory;
import pkg.Animal;

public class App {
  static AnimaisFactory animaisFactory;

  public static void main(String[] args) throws Exception {
    animaisFactory = AnimaisFactory.getInstance();

    Animal cao = animaisFactory.create(Animais.CAO);

    cao.emitirSom();

  }
}
