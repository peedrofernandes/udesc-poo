package pkg;

public class Gato {
  
}
