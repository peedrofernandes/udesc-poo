package pkg;

public class Cao implements Animal {
  public String emitirSom() {
    return "VAMO CCT";
  }
}
