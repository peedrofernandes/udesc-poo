package pkg;

public enum Animais {
  CAO("cão"),
  GATO("gato"),
  
}
