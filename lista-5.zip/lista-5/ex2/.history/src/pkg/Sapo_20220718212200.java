package pkg;

public class Sapo implements Animal {
  public String emitirSom() {
    return "Croac-croac!";
  }
}
