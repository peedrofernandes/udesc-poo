package pkg;

public interface Animal {
  String emitirSom();
}
