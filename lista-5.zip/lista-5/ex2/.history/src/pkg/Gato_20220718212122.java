package pkg;

public class Gato implements Animal {
  
}
