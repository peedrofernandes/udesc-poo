package pkg;

public class Rato implements Animal {
  public String emitirSom() {
    return "Quiiii "
  }
}
