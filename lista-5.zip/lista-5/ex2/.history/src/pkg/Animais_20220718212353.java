package pkg;

public enum Animais {
  
}
