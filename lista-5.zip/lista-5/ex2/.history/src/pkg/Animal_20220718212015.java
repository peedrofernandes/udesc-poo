package pkg;

public interface Animal {
  
}
