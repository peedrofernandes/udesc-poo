package pkg;

public class Cao implements Animal {
  public emitirSom() {
    
  }
}
