package pkg;

public enum Animais {
  CAO("cão"),
  GATO("gato"),
  RATO("rato"),
  SAPO("sapo"),
  COBRA("cobra");

  String tipo;
  
  public Animais(String tipo) {

  }

}
