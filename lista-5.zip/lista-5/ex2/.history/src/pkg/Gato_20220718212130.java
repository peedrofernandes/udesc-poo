package pkg;

public class Gato implements Animal {
  public String emitirSom() {
    return "Miau!";
  }
}
