package pkg;

public class Cobra implements Animal {
  public String emitirSom() {
    
  }
}
