package pkg;

public class AnimalFactory {
  public static Animal create(int )
}
