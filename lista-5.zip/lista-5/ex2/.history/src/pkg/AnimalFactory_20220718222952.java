package pkg;

public class AnimalFactory {
  public static Animal create(Animais desc) {
    if (desc = Animais.CAO)
  }
}
