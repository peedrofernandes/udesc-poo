import pkg.AnimaisFactory;

public class App {
  static nimaisFactory static animaisFactory;

  public static void main(String[] args) throws Exception {
    animaisFactory = AnimaisFactory.getInstance();

  }
}
