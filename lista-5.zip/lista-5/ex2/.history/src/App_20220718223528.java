import pkg.AnimaisFactory;

public class App {
  static nimaisFactory animaisFactory;

  public static void main(String[] args) throws Exception {
    animaisFactory = AnimaisFactory.getInstance();

  }
}
