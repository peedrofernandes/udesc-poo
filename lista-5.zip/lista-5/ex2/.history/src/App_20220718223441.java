import pkg.AnimaisFactory;

public class App {
  AnimaisFactory animaisFactory = AnimaisFactory.getInstance();

  public static void main(String[] args) throws Exception {


  }
}
