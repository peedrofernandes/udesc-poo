import pkg.AnimaisFactory;

public class App {
  AnimaisFactory animaisFactory;

  public static void main(String[] args) throws Exception {
    animaisFactory = AnimaisFactory.getInstance();

  }
}
