import pkg.AnimaisFactory;

public class App {
  static animaisFactory animaisFactory;

  public static void main(String[] args) throws Exception {
    animaisFactory = AnimaisFactory.getInstance();

  }
}
