import pkg.AnimaisFactory;

public class App {
  AnimaisFactory static animaisFactory;

  public static void main(String[] args) throws Exception {
    animaisFactory = AnimaisFactory.getInstance();

  }
}
