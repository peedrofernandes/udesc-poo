package factory;

public class PoligonFactory {
  public static Polygon createPolycon(int nSizes) {
    
  }
}
