package factory;

import java.util.Scanner;

public class MainTest {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    System.out.println("Digite o numero de lados do poligono que deseja criar: ");
    int nSizes = input.nextInt();

    Polygon = PolygonFactory.createPolygon(nSizes);

    input.close();
  }
}
