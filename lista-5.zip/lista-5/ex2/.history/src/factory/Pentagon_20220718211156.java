package factory;

public class Pentagon implements Polygon {
    
}
