package factory;

public interface Polygon {
  String getDescription();

  
}
