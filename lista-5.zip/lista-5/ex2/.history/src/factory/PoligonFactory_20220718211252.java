package factory;

public class PoligonFactory {
  public static Polygon createPolycon(int nSizes) {
    if (nSizes == 3) {
      
    }
  }
}
