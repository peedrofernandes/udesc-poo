package factory;

public class Pentagon implements Polygon {
  public String getDescription() {
    return "P"
  }
}
