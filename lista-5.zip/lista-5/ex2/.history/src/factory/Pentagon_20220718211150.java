package factory;

public class Pentagon {
  
}
