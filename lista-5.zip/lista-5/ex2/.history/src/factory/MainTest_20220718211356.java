package factory;

public class MainTest {
  public static void main(String[] args) {
    Polygon polygon
  }
}
