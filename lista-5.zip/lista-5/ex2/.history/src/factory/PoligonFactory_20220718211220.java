package factory;

public class PoligonFactory {
  
}
