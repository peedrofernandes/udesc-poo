package factory;

public class Square {
  
}
