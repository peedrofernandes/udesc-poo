package factory;

public class Triangle {
  
}
