package factory;

public class Square implements Polygon {
  public String getDescription() {
    return "Square";
  }
}
