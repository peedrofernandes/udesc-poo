package factory;

public interface Polygon {
  
}
