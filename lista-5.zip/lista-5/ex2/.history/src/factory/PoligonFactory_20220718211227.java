package factory;

public class PoligonFactory {
  public static Polygon
}
