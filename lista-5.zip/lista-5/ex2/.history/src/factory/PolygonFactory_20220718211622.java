package factory;

public class PolygonFactory {
  public static Polygon createPolygon(int nSizes) {
    if (nSizes == 3) {
      return new Triangle();
    } else if (nSizes == 4) {
      return new Square();
    } else if (nSizes == 5) {
      return new Pentagon();
    } else {
      return null;
    }
  }
}
