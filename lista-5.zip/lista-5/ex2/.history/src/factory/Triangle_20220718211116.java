package factory;

public class Triangle implements Polygon {
  public String getDescription() {
    return "Triangle";
  }
}
