package pkg;

import java.util.ArrayList;
import java.util.List;

public class Cliente implements Observador {
  List<String> mensagens;

  public Cliente() {
    this.mensagens = new ArrayList<>();
  }

  public void atualizar(Object objeto) {
    this.mensagens.add((String)objeto);
  }

  public List<String> getMensagens() {
    return this.mensagens;
  }

  public void addMensagem(String str) {
    this.mensagens.add(str);
  }
  
  public toString() {
    
  }
}
