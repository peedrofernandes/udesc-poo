package pkg;

import java.util.List;

public class Servidor implements Observador {
  private String ip;
  private String ultimaMensagem;

  public void enviarMensagem(String mensagem) {

  } 
}
