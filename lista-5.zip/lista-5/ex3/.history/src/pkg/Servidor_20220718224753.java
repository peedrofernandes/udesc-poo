package pkg;

import java.util.List;

public class Servidor implements Sujeito {
  private String ip;
  private String ultimaMensagem;
  private List<Observador> observadores;

  public void enviarMensagem(String mensagem) {
    for (Observador ob : this.observadores)
      notificar(ob);
  }
  
  notificar()
}
