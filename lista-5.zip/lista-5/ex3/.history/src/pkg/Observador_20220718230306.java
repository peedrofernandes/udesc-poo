package pkg;

public interface Observador <T> {
  void atualizar(T msg);
}
