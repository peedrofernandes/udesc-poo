package pkg;

import java.util.ArrayList;
import java.util.List;

public class Cliente implements Observador {
  List<String> mensagens;
  private String nome;

  public Cliente(String nome) {
    this.mensagens = new ArrayList<>();
  }

  public void atualizar(Object objeto) {
    this.mensagens.add((String)objeto);
  }

  public List<String> getMensagens() {
    return this.mensagens;
  }

  public void addMensagem(String str) {
    this.mensagens.add(str);
  }
  
  public String toString() {
    String str = "";
    int indice = 0;

    for (String mensagem : this.mensagens) {
      str += "Mensagem " + indice + ": " + mensagem + "\n";
      indice++;
    }

    return mensagem;
  }
}
