package pkg;

import java.util.Random;

public class Main {
  public static void main(String[] args) {

  }

  private String generateIP() {
    for (int i = 0; i < 4; i++) {
      Random randint = 
    }
  }
}
