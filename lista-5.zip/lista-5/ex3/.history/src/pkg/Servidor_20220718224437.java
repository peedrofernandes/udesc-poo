package pkg;

public class Servidor {
  private String ip;
  private String ultimaMensagem;
  private List<Observador> observadores;

  public void enviarMensagem(String mensagem) {

  } 
}
