package pkg;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
  List<String> mensagens;

  public Cliente() {
    this.mensagens = new ArrayList<>();
  }

  public List<String> getMensagens() {
    return this.mensagens;
  }

  public void addMensagem(String str) {
    this.mensagens.add(str);
  }
}
