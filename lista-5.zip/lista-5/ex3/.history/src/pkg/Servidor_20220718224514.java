package pkg;

import java.util.List;

public class Servidor implements  {
  private String ip;
  private String ultimaMensagem;

  public void enviarMensagem(String mensagem) {

  } 
}
