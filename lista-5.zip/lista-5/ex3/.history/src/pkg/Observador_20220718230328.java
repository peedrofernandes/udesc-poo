package pkg;

public interface Observador {
  void atualizar(T msg);
}
