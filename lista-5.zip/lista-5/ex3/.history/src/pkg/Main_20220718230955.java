package pkg;

import java.util.Random;

public class Main {
  public static void main(String[] args) {

  }

  private String generateIP() {
    Random randint = new Random();

    String ip = "";

    for (int i = 1; i <= 4; i++) {
      int number = randint.nextInt() % 256;
      ip += Integer.toString(number);
      if (i != 4)
        ip += ".";
    }
  }
}
