package pkg;

import java.util.List;

public class Servidor implements Sujeito {
  private String ip;
  private String ultimaMensagem;
  private List<Observador> observadores;

  public void enviarMensagem(String mensagem) {
    this.ultimaMensagem = mensagem;
    notificar(mensagem);
  }
  
  public void notificar(String mensagem) {
    for (Observador ob : this.observadores)
      ob.atualizar(mensagem);
  }
}
