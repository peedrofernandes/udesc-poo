package pkg;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
  List<String> mensagens;

  public Cliente() {
    this.mensagens = new ArrayList<>();
  }

  public List<String> getMensagens() {
    return this.mensagens;
  }
  public 
}
