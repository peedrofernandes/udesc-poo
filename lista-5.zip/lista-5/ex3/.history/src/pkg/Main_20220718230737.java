package pkg;

public class Main {
  public static void main(String[] args) {

  }

  private String generateIP() {
    for (int i = )
  }
}
