import java.util.LinkedList;
import java.util.List;

import pkg.GenericIterator;

public class App {
  private GenericIterator<Character> iterador;

  public static void main(String[] args) throws Exception {
    List<Character> lista = new LinkedList<>();

    lista.add('A');
    lista.add('A');
    lista.add('A');
    lista.add('A');
    lista.add('A');
    lista.add('A');
    lista.add('A');
    lista.add('A');
  }
}
