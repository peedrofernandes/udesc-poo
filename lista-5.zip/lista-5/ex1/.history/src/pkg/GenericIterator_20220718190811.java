package pkg;

import java.util.List;

public class GenericIterator<T> implements Iterator<T> {
  private List<T> lista;
  private int indiceAtual;

  public GenericIterator(List<T> lista) {
    this.lista = lista;
  }
}
