package pkg;

public class GenericIterator implements Iterador {
  
}
