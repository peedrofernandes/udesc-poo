package pkg;

public class EstruturaDados {
  
}
