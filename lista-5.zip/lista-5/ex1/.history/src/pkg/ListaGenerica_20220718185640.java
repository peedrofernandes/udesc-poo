package pkg;

public class ListaGenerica <T> {
  
}
