package pkg;

public class IteradorEstruturaDados {
  public IteradorEstruturaDados(EstruturaDados d) {
    
  }
}
