package pkg;

import java.util.List;

public class ListaGenerica<T> {
  private List<T> lista;
  private Iterador<T>
}
