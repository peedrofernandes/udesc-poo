package pkg;

public interface Iterador {
  
}
