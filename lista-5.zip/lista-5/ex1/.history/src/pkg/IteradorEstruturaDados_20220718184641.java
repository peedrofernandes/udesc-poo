package pkg;

public class IteradorEstruturaDados <T> implements {
  private EstruturaDados estruturaDados;

  public IteradorEstruturaDados(EstruturaDados d) {
    this.estruturaDados = d;
  }


}
