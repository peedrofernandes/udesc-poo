package pkg;

public interface Iterador <T> {
  
}
