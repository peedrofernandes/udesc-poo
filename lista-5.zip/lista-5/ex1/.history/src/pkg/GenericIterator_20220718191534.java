package pkg;

import java.util.List;

public class GenericIterator<T> implements Iterator<T> {
  private List<T> lista;
  private int indiceAtual;

  public GenericIterator(List<T> lista) {
    this.lista = lista;
    this.indiceAtual = -1;
  }

  public boolean hasNext() {
    if (lista.get(this.indiceAtual + 1) != null)
      return true;
    else
      return false;
  }

  public T next() {
    this.indiceAtual++;
    return this.lista.get(indiceAtual);
  }

  public void reset() {
    this.indiceAtual = -1;
  }

  public List<T> evensOdds() 
}
