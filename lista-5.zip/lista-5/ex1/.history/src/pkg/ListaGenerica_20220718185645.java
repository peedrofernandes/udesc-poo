package pkg;

public class ListaGenerica <T> {
  private List<T> lista;
}
