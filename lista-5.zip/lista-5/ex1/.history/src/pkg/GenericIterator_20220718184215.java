package pkg;

public class GenericIterator <T> implements Iterador {
  
}
