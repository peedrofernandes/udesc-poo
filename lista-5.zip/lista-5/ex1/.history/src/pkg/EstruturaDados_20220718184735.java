package pkg;

public class EstruturaDados<T> {
  private List<T> 
}
