package pkg;

import java.util.List;

public class GenericIterator<T> implements Iterator<T> {
  private List<T> lista;
  private int indiceAtual;

  public GenericIterator(List<T> lista) {
    this.lista = lista;
  }

  public boolean hasNext() {
    if (lista.get(this.indiceAtual + 1) != null)
      return true;
    else
      return false;
  }

  public T next() {
    if (this.indiceAtual == null)
      
  }

  public void reset() {
    this.indiceAtual = 0;
  }
}
