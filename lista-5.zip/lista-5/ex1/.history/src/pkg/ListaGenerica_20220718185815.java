package pkg;

import java.util.Iterator;
import java.util.List;

public class ListaGenerica<T> {
  private List<T> lista;
  private Iterator<T> = new 
}
