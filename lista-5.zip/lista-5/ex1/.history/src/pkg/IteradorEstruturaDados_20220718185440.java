package pkg;

public class IteradorEstruturaDados <T> implements Iterador <T> {
  private EstruturaDados<T> estruturaDados;

  public IteradorEstruturaDados(EstruturaDados<T> d) {
    this.estruturaDados = d;
  }

  public boolean hasNext() {

  }
}
