package pkg;

public interface Iterador <T> {
  public abstract boolean hasNext();
}
