package pkg;

public class EstruturaDados <T> {
  public T get() {
    
  }
}
