package pkg;

public class IteradorEstruturaDados {
  private EstruturaDados d;

  public IteradorEstruturaDados(EstruturaDados d) {
    this.estruturaDados = d;
  }
}
