package pkg;

public interface Iterator {
  
}
