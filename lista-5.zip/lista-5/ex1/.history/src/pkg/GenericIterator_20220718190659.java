package pkg;

public class GenericIterator<T> implements Iterator<T> {
  
}
