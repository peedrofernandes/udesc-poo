package pkg;

public class Elemento <T> {
  
}
