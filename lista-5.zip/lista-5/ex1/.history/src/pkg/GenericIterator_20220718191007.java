package pkg;

import java.util.List;

public class GenericIterator<T> implements Iterator<T> {
  private List<T> lista;
  private int indiceAtual;

  public GenericIterator(List<T> lista) {
    this.lista = lista;
    this.indiceAtual = 0;
  }

  public boolean hasNext() {
    if (lista.get(this.indiceAtual + 1) != null)
      return true;
    else
      return false;
  }

  public T next() {
    this.indiceAtual++;
  }
}
