package pkg;

public class IteradorEstruturaDados <T> implements Iterador <T> {
  private EstruturaDados estruturaDados;

  public IteradorEstruturaDados(EstruturaDados<T> d) {
    this.estruturaDados = d;
  }

  public T hasNext() {

  }
}
