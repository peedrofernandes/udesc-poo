package pkg;

public class Lista {
  private List<T>
}
