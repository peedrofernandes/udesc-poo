package pkg;

import java.util.List;

public class EstruturaDados <T> {
  private List<T> lista;
  
  public EstruturaDados() {
    this.lista = new ArrayList<>();
  }

  
}
