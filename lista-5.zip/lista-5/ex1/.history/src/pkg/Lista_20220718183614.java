package pkg;

import java.util.List;

public class Lista <T> {
  private List<T>
}
