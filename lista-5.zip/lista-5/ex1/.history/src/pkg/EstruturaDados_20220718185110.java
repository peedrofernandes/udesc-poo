package pkg;

import java.util.ArrayList;
import java.util.List;

public class EstruturaDados <T> {
  private List<T> lista;
  
  public EstruturaDados() {
    this.lista = new ArrayList<>();
  }

  public T get(int index) {

  }

  public void set(int index, T elem) {
    this.lista.set(index, elem);
  }

  public int size() {
    return this.lista.size();
  }
}
