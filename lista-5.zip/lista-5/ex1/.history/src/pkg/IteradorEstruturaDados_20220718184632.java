package pkg;

public class IteradorEstruturaDados {
  private EstruturaDados estruturaDados;

  public IteradorEstruturaDados(EstruturaDados d) {
    this.estruturaDados = d;
  }
}
